package com.reto.adminusuarios.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;
import com.reto.adminusuarios.entity.*;
@Repository("CustomersRepository")
public interface RepositoryCustomers extends CrudRepository<Clientes,String>{
   int deleteByIDSTUDENT(String id);
}
