package com.reto.adminusuarios.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.reto.adminusuarios.entity.GetNewId;


@Repository("getNewIdRepository")
public interface RepositoryGetNewId extends CrudRepository<GetNewId,String>{
   @Query(value="SELECT ROUND(DBMS_RANDOM.VALUE(11111111111111111111,99999999999999999999)) id FROM DUAL", nativeQuery=true)
   GetNewId getId();
}
