package com.reto.adminusuarios.services.implement;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.reto.adminusuarios.entity.Clientes;
import com.reto.adminusuarios.repository.RepositoryCustomers;
import com.reto.adminusuarios.repository.RepositoryGetNewId;
import com.reto.adminusuarios.services.serviceCustomers;

@Service("CustomerServiceImpl")
@Transactional
public class ServiceImplCustomers implements serviceCustomers {

	@Autowired
	@Qualifier("CustomersRepository")
	
	private RepositoryCustomers repositoryCustomers;
	
	
	@Autowired
	@Qualifier("getNewIdRepository")
	
	private RepositoryGetNewId repositoryGetNewId;
	
	@Override
	public List<Clientes> listAllCustomers() {
		// TODO Auto-generated method stub
		return (List<Clientes>) repositoryCustomers.findAll();
	}

	@Override
	public Optional<Clientes> findByIdClientes(String id) {
		// TODO Auto-generated method stub
		return repositoryCustomers.findById(id);
	}

	@Override
	public Clientes updateCustomers(Clientes cliente) {
		// TODO Auto-generated method stub
		return repositoryCustomers.save(cliente);
	}

	@Override
	public int removeClientes(String id) {
		// TODO Auto-generated method stub
		return repositoryCustomers.deleteByIDSTUDENT(id);
	}

	@Override
	public Clientes newCustomers(Clientes cliente) {
		// TODO Auto-generated method stub
		String id = repositoryGetNewId.getId().getId();
		Clientes c = new Clientes();
		c.setIDSTUDENT(id);
		c.setNAME(cliente.getNAME());
		c.setAGE(cliente.getAGE());
		c.setPROGRAMA(cliente.getPROGRAMA());
		return repositoryCustomers.save(c);
	}

}
