package com.reto.adminusuarios.services;
import java.util.*;
import com.reto.adminusuarios.entity.*;
public interface serviceCustomers {
   public abstract List<Clientes> listAllCustomers();
   public abstract Optional<Clientes> findByIdClientes(String id);
   public abstract Clientes updateCustomers(Clientes cliente);
   public abstract int removeClientes(String id);
   public abstract Clientes newCustomers(Clientes cliente);

}
