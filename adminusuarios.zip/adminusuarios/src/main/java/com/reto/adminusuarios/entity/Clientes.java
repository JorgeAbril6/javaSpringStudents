package com.reto.adminusuarios.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STUDENTS")
public class Clientes {
  @Id
  private String IDSTUDENT;
  private String NAME;
  private String AGE;
  private String PROGRAMA;
public String getIDSTUDENT() {
	return IDSTUDENT;
}
public void setIDSTUDENT(String iDC) {
	IDSTUDENT = iDC;
}
public String getNAME() {
	return NAME;
}
public void setNAME(String nAMEC) {
	NAME = nAMEC;
}
public String getAGE() {
	return AGE;
}
public void setAGE(String aGE) {
	AGE = aGE;
}
public String getPROGRAMA() {
	return PROGRAMA;
}
public void setPROGRAMA(String sKILLS) {
	PROGRAMA = sKILLS;
}

  
}
